# VisionOS AR — Android App

> Apple Vision Pro–style AR/VR experience for Android.  
> Google Cardboard VR · MediaPipe Hand Tracking · WebXR · Three.js

---

## 🚀 Features

| Feature | Details |
|---|---|
| Hand Tracking | MediaPipe Hands — pinch, grab, swipe, drag |
| Two-hand support | Left + right hand skeleton rendering |
| Virtual cursor | Index fingertip cursor |
| AR Passthrough | Live camera feed as background |
| VR Cardboard | Split-screen stereo + fullscreen immersive |
| Head Tracking | DeviceOrientation API |
| Gesture Training | Score system with streak counter |
| Vision Pro UI | Glassmorphism · Neon · Spatial windows · 3D panels |
| WebXR | `immersive-ar` / `immersive-vr` session support |
| GPU Accelerated | Three.js WebGL renderer, 60 FPS target |

---

## 📁 Project Structure

```
visionos-ar/
├── index.html              # Main UI shell
├── style.css               # Vision Pro glassmorphism design
├── app.js                  # Three.js + MediaPipe + WebXR logic
├── package.json
├── capacitor.config.ts     # Capacitor Android config
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml
└── .github/
    └── workflows/
        └── build-apk.yml   # Auto APK build
```

---

## 🛠️ Local Setup

### Prerequisites

- Node.js 18+ 
- Android Studio (for `cap open android`)
- Android SDK (API 22+)

### Steps

```bash
# 1. Clone your repo
git clone https://github.com/YOUR_USERNAME/visionos-ar.git
cd visionos-ar

# 2. Install dependencies
npm install

# 3. Build web assets
npm run build

# 4. Initialize Capacitor Android project (first time only)
npx cap add android

# 5. Sync web assets into Android project
npx cap sync android

# 6. Open in Android Studio to build & run
npx cap open android
```

In Android Studio: **Run → Run 'app'** or **Build → Build APK**.

---

## ☁️ GitHub Actions — Auto APK Build

### Setup

1. Push this project to a GitHub repository.
2. Go to **Actions** tab → **Android APK Build** → **Run workflow**.
3. The APK will appear under **Artifacts** when the build finishes.

### Trigger Options

- **Manual**: `workflow_dispatch` — use the Run button in GitHub Actions.
- **Auto on push**: any push to `main` that changes source files triggers a build.

### Download APK

1. Go to **Actions → Android APK Build → latest run**.
2. Scroll to **Artifacts** section.
3. Download `VisionOS-AR-debug-apk.zip`.
4. Unzip → install the `.apk` on your Android device.

---

## 📱 Install APK on Android

1. Enable **Settings → Security → Install unknown apps** for your file manager.
2. Copy the `.apk` to your phone.
3. Tap the `.apk` file → Install.
4. Grant **Camera** permission when prompted.

---

## 🥽 Using VR Cardboard Mode

1. Open the app → tap **VR** in the dock.
2. The screen splits into left/right stereo view.
3. Insert phone into Google Cardboard viewer.
4. Head movement rotates the 3D scene.
5. Tap **EXIT** or shake to return to AR mode.

---

## ✋ Hand Gestures

| Gesture | How to do it |
|---|---|
| **Pinch** | Touch thumb + index fingertip together |
| **Grab** | Curl all fingers into a fist |
| **Swipe** | Move hand quickly left or right |
| **Drag** | Open hand, move steadily |

Open **Train** mode to practice all gestures with a score system.

---

## 🔑 Signed Release APK (Optional)

To build a signed release APK for Google Play:

1. Generate a keystore:
   ```bash
   keytool -genkey -v -keystore release.jks -alias visionosar -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Add secrets to your GitHub repo (**Settings → Secrets → Actions**):
   - `KEYSTORE_FILE` — base64 encoded keystore
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`

3. Uncomment the release build section in `.github/workflows/build-apk.yml`.

---

## ⚙️ Performance Tips

- Keep **Skeleton Overlay** off for +5 FPS on low-end devices.
- Set **FPS Limit** to 30 to save battery.
- Use **AR Passthrough off** (black background) for best VR performance.
- MediaPipe runs at 480p regardless of camera resolution.

---

## 🧩 Tech Stack

- **Three.js r128** — 3D rendering
- **MediaPipe Hands** — real-time hand landmark detection
- **WebXR Device API** — immersive VR/AR sessions
- **Capacitor 5** — Web → Android APK bridge
- **GitHub Actions** — CI/CD APK builder

---

## 📄 License

MIT — free to use and modify.
